# pm-hw-1

Linear and Logistic Regression performed on the Kaggle fish dataset found [here](https://www.kaggle.com/aungpyaeap/fish-market)

* Linear Regression seeks to predict weight of fish

* Logistic Regression seeks to predict species of fish



